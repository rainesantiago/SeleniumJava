package Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import java.util.concurrent.TimeUnit;

public class SearchResultPage{

    WebDriver driver;

    public SearchResultPage(WebDriver driver)
    {
        this.driver = driver;
        driver.get("https://www.amazon.com");
        driver.manage().window().maximize();
    
        // driver.findElement(By.id("twotabsearchtextbox")).sendKeys("iPhone");
        // driver.findElement(By.id("nav-search-submit-button")).click();
        // driver.findElement(By.xpath("//div[@id='departments']//li/span/a/span")).click();
    }
    
    By searchField = By.id("twotabsearchtextbox");
    By searchButton = By.cssSelector("#nav-search-submit-button");
    By rangeMinField = By.cssSelector("#low-price");
    

    public void AmazonSearch(String searchName){
        driver.findElement(searchField).sendKeys(searchName);
        driver.findElement(searchButton).click();
    }

    public void SelectDepartment(String departmentName){
        String departmentOption = "//div[@id='departments']//li/span/a/span[text()='"+departmentName+"']";
        driver.findElement(By.xpath(departmentOption)).click();
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

    }

    public void SearchPriceRange(String inputMin){
        driver.findElement(rangeMinField).sendKeys(inputMin);
        // driver.findElement(searchButton).click();
    }
}
