package Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class App {

    public static void main(String[] args) throws Exception {
     
        System.setProperty("webdriver.chrome.driver", "C:/Program Files/seleniumchrome/chromedriver.exe");
        System.out.println("Hello, World!");
        WebDriver driver = new ChromeDriver();

        SearchResultPage test = new SearchResultPage(driver);
        test.AmazonSearch("iphone");
        test.SelectDepartment("Cell Phones");
        test.SearchPriceRange("400");
        
        driver.close();
    }

}